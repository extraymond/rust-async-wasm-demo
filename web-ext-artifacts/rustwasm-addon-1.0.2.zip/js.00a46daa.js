// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"node_modules/parcel-bundler/src/builtins/bundle-url.js":[function(require,module,exports) {
var bundleURL = null;

function getBundleURLCached() {
  if (!bundleURL) {
    bundleURL = getBundleURL();
  }

  return bundleURL;
}

function getBundleURL() {
  // Attempt to find the URL of the current script and use that as the base URL
  try {
    throw new Error();
  } catch (err) {
    var matches = ('' + err.stack).match(/(https?|file|ftp|chrome-extension|moz-extension):\/\/[^)\n]+/g);

    if (matches) {
      return getBaseURL(matches[0]);
    }
  }

  return '/';
}

function getBaseURL(url) {
  return ('' + url).replace(/^((?:https?|file|ftp|chrome-extension|moz-extension):\/\/.+)\/[^/]+$/, '$1') + '/';
}

exports.getBundleURL = getBundleURLCached;
exports.getBaseURL = getBaseURL;
},{}],"node_modules/parcel-bundler/src/builtins/css-loader.js":[function(require,module,exports) {
var bundle = require('./bundle-url');

function updateLink(link) {
  var newLink = link.cloneNode();

  newLink.onload = function () {
    link.remove();
  };

  newLink.href = link.href.split('?')[0] + '?' + Date.now();
  link.parentNode.insertBefore(newLink, link.nextSibling);
}

var cssTimeout = null;

function reloadCSS() {
  if (cssTimeout) {
    return;
  }

  cssTimeout = setTimeout(function () {
    var links = document.querySelectorAll('link[rel="stylesheet"]');

    for (var i = 0; i < links.length; i++) {
      if (bundle.getBaseURL(links[i].href) === bundle.getBundleURL()) {
        updateLink(links[i]);
      }
    }

    cssTimeout = null;
  }, 50);
}

module.exports = reloadCSS;
},{"./bundle-url":"node_modules/parcel-bundler/src/builtins/bundle-url.js"}],"node_modules/bulma/bulma.sass":[function(require,module,exports) {

        var reloadCSS = require('_css_loader');
        module.hot.dispose(reloadCSS);
        module.hot.accept(reloadCSS);
      
},{"_css_loader":"node_modules/parcel-bundler/src/builtins/css-loader.js"}],"crate/Cargo.toml":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__wbindgen_closure_wrapper1029 = exports.__wbindgen_closure_wrapper754 = exports.__wbindgen_closure_wrapper2421 = exports.__wbindgen_closure_wrapper758 = exports.__wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4 = exports.__wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29 = exports.__wbindgen_json_serialize = exports.__widl_f_json_Response = exports.__widl_instanceof_Response = exports.__widl_f_fetch_with_request_Window = exports.__widl_f_new_with_str_and_init_Request = exports.__wbindgen_string_new = exports.__wbg_new_abadb45e63451a4b = exports.__wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd = exports.__wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69 = exports.__wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d = exports.__wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50 = exports.__wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d = exports.__wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4 = exports.__wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f = exports.__wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea = exports.__wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8 = exports.__wbindgen_throw = exports.__wbindgen_debug_string = exports.__wbg_error_4bb6c2a97407129a = exports.__wbg_stack_558ba5917b466edd = exports.__wbg_new_59cb74e423758ede = exports.__wbg_set_09ce0f7f67d68b09 = exports.__wbg_call_1fc553129cb17c3c = exports.__wbg_newnoargs_368b05293a3f44de = exports.__wbindgen_is_undefined = exports.__wbg_global_2c090b42ef2744b9 = exports.__wbg_window_425d3fa09c43ece4 = exports.__wbg_self_937dd9f384d2384a = exports.__wbg_globalThis_8df2c73db5eac245 = exports.__wbg_then_fb82bfc0e1d7f311 = exports.__wbg_then_3bb8a69ecfd29434 = exports.__wbg_resolve_4ca5ad5c0eb0abf1 = exports.__widl_instanceof_Window = exports.__widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window = exports.__widl_f_now_Performance = exports.__widl_f_performance_Window = exports.__wbindgen_cb_drop = exports.__wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278 = exports.__wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe = exports.__wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9 = exports.__wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd = exports.__wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062 = exports.__wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3 = exports.__wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836 = exports.__wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37 = exports.__wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e = exports.__wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab = exports.__wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689 = exports.__wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23 = exports.__wbindgen_cb_forget = exports.__wbindgen_object_drop_ref = exports.__wbg_wasmbindgeninitialize_a48a748cf08ec22f = exports.__wbindgen_function_table = exports.__wbindgen_memory = exports.__wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234 = exports.__wbindgen_object_clone_ref = exports.__wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496 = exports.__wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d = exports.__wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650 = exports.__wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c = exports.__wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834 = exports.__wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e = exports.__wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba = exports.__wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b = exports.__wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf = exports.__wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0 = exports.__wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007 = exports.__wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395 = exports.__wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56 = exports.__wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d = exports.__wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff = exports.__wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0 = exports.__wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631 = exports.__wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344 = exports.__wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087 = exports.__wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452 = exports.__wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24 = exports.__wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e = exports.__wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736 = exports.__wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f = exports.run = exports.default = void 0;

var _rust_parcel_bg = _interopRequireDefault(require("./pkg/rust_parcel_bg.wasm"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _default = _rust_parcel_bg.default;
exports.default = _default;
var run = _rust_parcel_bg.default.run;
exports.run = run;
var __wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f = _rust_parcel_bg.default.__wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f;
exports.__wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f = __wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f;
var __wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736 = _rust_parcel_bg.default.__wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736;
exports.__wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736 = __wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736;
var __wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e = _rust_parcel_bg.default.__wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e;
exports.__wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e = __wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e;
var __wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24 = _rust_parcel_bg.default.__wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24;
exports.__wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24 = __wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24;
var __wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452 = _rust_parcel_bg.default.__wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452;
exports.__wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452 = __wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452;
var __wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087 = _rust_parcel_bg.default.__wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087;
exports.__wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087 = __wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087;
var __wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344 = _rust_parcel_bg.default.__wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344;
exports.__wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344 = __wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344;
var __wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631 = _rust_parcel_bg.default.__wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631;
exports.__wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631 = __wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631;
var __wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0 = _rust_parcel_bg.default.__wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0;
exports.__wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0 = __wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0;
var __wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff = _rust_parcel_bg.default.__wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff;
exports.__wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff = __wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff;
var __wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d = _rust_parcel_bg.default.__wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d;
exports.__wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d = __wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d;
var __wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56 = _rust_parcel_bg.default.__wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56;
exports.__wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56 = __wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56;
var __wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395 = _rust_parcel_bg.default.__wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395;
exports.__wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395 = __wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395;
var __wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007 = _rust_parcel_bg.default.__wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007;
exports.__wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007 = __wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007;
var __wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0 = _rust_parcel_bg.default.__wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0;
exports.__wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0 = __wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0;
var __wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf = _rust_parcel_bg.default.__wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf;
exports.__wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf = __wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf;
var __wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b = _rust_parcel_bg.default.__wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b;
exports.__wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b = __wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b;
var __wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba = _rust_parcel_bg.default.__wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba;
exports.__wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba = __wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba;
var __wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e = _rust_parcel_bg.default.__wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e;
exports.__wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e = __wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e;
var __wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834 = _rust_parcel_bg.default.__wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834;
exports.__wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834 = __wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834;
var __wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c = _rust_parcel_bg.default.__wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c;
exports.__wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c = __wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c;
var __wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650 = _rust_parcel_bg.default.__wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650;
exports.__wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650 = __wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650;
var __wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d = _rust_parcel_bg.default.__wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d;
exports.__wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d = __wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d;
var __wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496 = _rust_parcel_bg.default.__wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496;
exports.__wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496 = __wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496;
var __wbindgen_object_clone_ref = _rust_parcel_bg.default.__wbindgen_object_clone_ref;
exports.__wbindgen_object_clone_ref = __wbindgen_object_clone_ref;
var __wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234 = _rust_parcel_bg.default.__wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234;
exports.__wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234 = __wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234;
var __wbindgen_memory = _rust_parcel_bg.default.__wbindgen_memory;
exports.__wbindgen_memory = __wbindgen_memory;
var __wbindgen_function_table = _rust_parcel_bg.default.__wbindgen_function_table;
exports.__wbindgen_function_table = __wbindgen_function_table;
var __wbg_wasmbindgeninitialize_a48a748cf08ec22f = _rust_parcel_bg.default.__wbg_wasmbindgeninitialize_a48a748cf08ec22f;
exports.__wbg_wasmbindgeninitialize_a48a748cf08ec22f = __wbg_wasmbindgeninitialize_a48a748cf08ec22f;
var __wbindgen_object_drop_ref = _rust_parcel_bg.default.__wbindgen_object_drop_ref;
exports.__wbindgen_object_drop_ref = __wbindgen_object_drop_ref;
var __wbindgen_cb_forget = _rust_parcel_bg.default.__wbindgen_cb_forget;
exports.__wbindgen_cb_forget = __wbindgen_cb_forget;
var __wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23 = _rust_parcel_bg.default.__wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23;
exports.__wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23 = __wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23;
var __wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689 = _rust_parcel_bg.default.__wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689;
exports.__wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689 = __wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689;
var __wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab = _rust_parcel_bg.default.__wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab;
exports.__wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab = __wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab;
var __wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e = _rust_parcel_bg.default.__wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e;
exports.__wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e = __wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e;
var __wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37 = _rust_parcel_bg.default.__wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37;
exports.__wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37 = __wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37;
var __wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836 = _rust_parcel_bg.default.__wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836;
exports.__wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836 = __wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836;
var __wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3 = _rust_parcel_bg.default.__wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3;
exports.__wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3 = __wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3;
var __wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062 = _rust_parcel_bg.default.__wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062;
exports.__wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062 = __wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062;
var __wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd = _rust_parcel_bg.default.__wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd;
exports.__wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd = __wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd;
var __wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9 = _rust_parcel_bg.default.__wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9;
exports.__wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9 = __wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9;
var __wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe = _rust_parcel_bg.default.__wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe;
exports.__wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe = __wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe;
var __wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278 = _rust_parcel_bg.default.__wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278;
exports.__wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278 = __wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278;
var __wbindgen_cb_drop = _rust_parcel_bg.default.__wbindgen_cb_drop;
exports.__wbindgen_cb_drop = __wbindgen_cb_drop;
var __widl_f_performance_Window = _rust_parcel_bg.default.__widl_f_performance_Window;
exports.__widl_f_performance_Window = __widl_f_performance_Window;
var __widl_f_now_Performance = _rust_parcel_bg.default.__widl_f_now_Performance;
exports.__widl_f_now_Performance = __widl_f_now_Performance;
var __widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window = _rust_parcel_bg.default.__widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window;
exports.__widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window = __widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window;
var __widl_instanceof_Window = _rust_parcel_bg.default.__widl_instanceof_Window;
exports.__widl_instanceof_Window = __widl_instanceof_Window;
var __wbg_resolve_4ca5ad5c0eb0abf1 = _rust_parcel_bg.default.__wbg_resolve_4ca5ad5c0eb0abf1;
exports.__wbg_resolve_4ca5ad5c0eb0abf1 = __wbg_resolve_4ca5ad5c0eb0abf1;
var __wbg_then_3bb8a69ecfd29434 = _rust_parcel_bg.default.__wbg_then_3bb8a69ecfd29434;
exports.__wbg_then_3bb8a69ecfd29434 = __wbg_then_3bb8a69ecfd29434;
var __wbg_then_fb82bfc0e1d7f311 = _rust_parcel_bg.default.__wbg_then_fb82bfc0e1d7f311;
exports.__wbg_then_fb82bfc0e1d7f311 = __wbg_then_fb82bfc0e1d7f311;
var __wbg_globalThis_8df2c73db5eac245 = _rust_parcel_bg.default.__wbg_globalThis_8df2c73db5eac245;
exports.__wbg_globalThis_8df2c73db5eac245 = __wbg_globalThis_8df2c73db5eac245;
var __wbg_self_937dd9f384d2384a = _rust_parcel_bg.default.__wbg_self_937dd9f384d2384a;
exports.__wbg_self_937dd9f384d2384a = __wbg_self_937dd9f384d2384a;
var __wbg_window_425d3fa09c43ece4 = _rust_parcel_bg.default.__wbg_window_425d3fa09c43ece4;
exports.__wbg_window_425d3fa09c43ece4 = __wbg_window_425d3fa09c43ece4;
var __wbg_global_2c090b42ef2744b9 = _rust_parcel_bg.default.__wbg_global_2c090b42ef2744b9;
exports.__wbg_global_2c090b42ef2744b9 = __wbg_global_2c090b42ef2744b9;
var __wbindgen_is_undefined = _rust_parcel_bg.default.__wbindgen_is_undefined;
exports.__wbindgen_is_undefined = __wbindgen_is_undefined;
var __wbg_newnoargs_368b05293a3f44de = _rust_parcel_bg.default.__wbg_newnoargs_368b05293a3f44de;
exports.__wbg_newnoargs_368b05293a3f44de = __wbg_newnoargs_368b05293a3f44de;
var __wbg_call_1fc553129cb17c3c = _rust_parcel_bg.default.__wbg_call_1fc553129cb17c3c;
exports.__wbg_call_1fc553129cb17c3c = __wbg_call_1fc553129cb17c3c;
var __wbg_set_09ce0f7f67d68b09 = _rust_parcel_bg.default.__wbg_set_09ce0f7f67d68b09;
exports.__wbg_set_09ce0f7f67d68b09 = __wbg_set_09ce0f7f67d68b09;
var __wbg_new_59cb74e423758ede = _rust_parcel_bg.default.__wbg_new_59cb74e423758ede;
exports.__wbg_new_59cb74e423758ede = __wbg_new_59cb74e423758ede;
var __wbg_stack_558ba5917b466edd = _rust_parcel_bg.default.__wbg_stack_558ba5917b466edd;
exports.__wbg_stack_558ba5917b466edd = __wbg_stack_558ba5917b466edd;
var __wbg_error_4bb6c2a97407129a = _rust_parcel_bg.default.__wbg_error_4bb6c2a97407129a;
exports.__wbg_error_4bb6c2a97407129a = __wbg_error_4bb6c2a97407129a;
var __wbindgen_debug_string = _rust_parcel_bg.default.__wbindgen_debug_string;
exports.__wbindgen_debug_string = __wbindgen_debug_string;
var __wbindgen_throw = _rust_parcel_bg.default.__wbindgen_throw;
exports.__wbindgen_throw = __wbindgen_throw;
var __wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8 = _rust_parcel_bg.default.__wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8;
exports.__wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8 = __wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8;
var __wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea = _rust_parcel_bg.default.__wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea;
exports.__wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea = __wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea;
var __wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f = _rust_parcel_bg.default.__wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f;
exports.__wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f = __wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f;
var __wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4 = _rust_parcel_bg.default.__wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4;
exports.__wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4 = __wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4;
var __wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d = _rust_parcel_bg.default.__wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d;
exports.__wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d = __wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d;
var __wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50 = _rust_parcel_bg.default.__wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50;
exports.__wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50 = __wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50;
var __wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d = _rust_parcel_bg.default.__wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d;
exports.__wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d = __wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d;
var __wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69 = _rust_parcel_bg.default.__wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69;
exports.__wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69 = __wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69;
var __wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd = _rust_parcel_bg.default.__wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd;
exports.__wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd = __wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd;
var __wbg_new_abadb45e63451a4b = _rust_parcel_bg.default.__wbg_new_abadb45e63451a4b;
exports.__wbg_new_abadb45e63451a4b = __wbg_new_abadb45e63451a4b;
var __wbindgen_string_new = _rust_parcel_bg.default.__wbindgen_string_new;
exports.__wbindgen_string_new = __wbindgen_string_new;
var __widl_f_new_with_str_and_init_Request = _rust_parcel_bg.default.__widl_f_new_with_str_and_init_Request;
exports.__widl_f_new_with_str_and_init_Request = __widl_f_new_with_str_and_init_Request;
var __widl_f_fetch_with_request_Window = _rust_parcel_bg.default.__widl_f_fetch_with_request_Window;
exports.__widl_f_fetch_with_request_Window = __widl_f_fetch_with_request_Window;
var __widl_instanceof_Response = _rust_parcel_bg.default.__widl_instanceof_Response;
exports.__widl_instanceof_Response = __widl_instanceof_Response;
var __widl_f_json_Response = _rust_parcel_bg.default.__widl_f_json_Response;
exports.__widl_f_json_Response = __widl_f_json_Response;
var __wbindgen_json_serialize = _rust_parcel_bg.default.__wbindgen_json_serialize;
exports.__wbindgen_json_serialize = __wbindgen_json_serialize;
var __wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29 = _rust_parcel_bg.default.__wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29;
exports.__wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29 = __wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29;
var __wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4 = _rust_parcel_bg.default.__wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4;
exports.__wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4 = __wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4;
var __wbindgen_closure_wrapper758 = _rust_parcel_bg.default.__wbindgen_closure_wrapper758;
exports.__wbindgen_closure_wrapper758 = __wbindgen_closure_wrapper758;
var __wbindgen_closure_wrapper2421 = _rust_parcel_bg.default.__wbindgen_closure_wrapper2421;
exports.__wbindgen_closure_wrapper2421 = __wbindgen_closure_wrapper2421;
var __wbindgen_closure_wrapper754 = _rust_parcel_bg.default.__wbindgen_closure_wrapper754;
exports.__wbindgen_closure_wrapper754 = __wbindgen_closure_wrapper754;
var __wbindgen_closure_wrapper1029 = _rust_parcel_bg.default.__wbindgen_closure_wrapper1029;
exports.__wbindgen_closure_wrapper1029 = __wbindgen_closure_wrapper1029;
},{"./pkg/rust_parcel_bg.wasm":"crate/pkg/rust_parcel_bg.wasm"}],"js/index.js":[function(require,module,exports) {
"use strict";

require("bulma");

var _Cargo = _interopRequireDefault(require("../crate/Cargo.toml"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_Cargo.default.run();
},{"bulma":"node_modules/bulma/bulma.sass","../crate/Cargo.toml":"crate/Cargo.toml"}],"node_modules/parcel-bundler/src/builtins/hmr-runtime.js":[function(require,module,exports) {
var global = arguments[3];
var OVERLAY_ID = '__parcel__error__overlay__';
var OldModule = module.bundle.Module;

function Module(moduleName) {
  OldModule.call(this, moduleName);
  this.hot = {
    data: module.bundle.hotData,
    _acceptCallbacks: [],
    _disposeCallbacks: [],
    accept: function (fn) {
      this._acceptCallbacks.push(fn || function () {});
    },
    dispose: function (fn) {
      this._disposeCallbacks.push(fn);
    }
  };
  module.bundle.hotData = null;
}

module.bundle.Module = Module;
var checkedAssets, assetsToAccept;
var parent = module.bundle.parent;

if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== 'undefined') {
  var hostname = "" || location.hostname;
  var protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = new WebSocket(protocol + '://' + hostname + ':' + "38647" + '/');

  ws.onmessage = function (event) {
    checkedAssets = {};
    assetsToAccept = [];
    var data = JSON.parse(event.data);

    if (data.type === 'update') {
      var handled = false;
      data.assets.forEach(function (asset) {
        if (!asset.isNew) {
          var didAccept = hmrAcceptCheck(global.parcelRequire, asset.id);

          if (didAccept) {
            handled = true;
          }
        }
      }); // Enable HMR for CSS by default.

      handled = handled || data.assets.every(function (asset) {
        return asset.type === 'css' && asset.generated.js;
      });

      if (handled) {
        console.clear();
        data.assets.forEach(function (asset) {
          hmrApply(global.parcelRequire, asset);
        });
        assetsToAccept.forEach(function (v) {
          hmrAcceptRun(v[0], v[1]);
        });
      } else {
        window.location.reload();
      }
    }

    if (data.type === 'reload') {
      ws.close();

      ws.onclose = function () {
        location.reload();
      };
    }

    if (data.type === 'error-resolved') {
      console.log('[parcel] ✨ Error resolved');
      removeErrorOverlay();
    }

    if (data.type === 'error') {
      console.error('[parcel] 🚨  ' + data.error.message + '\n' + data.error.stack);
      removeErrorOverlay();
      var overlay = createErrorOverlay(data);
      document.body.appendChild(overlay);
    }
  };
}

function removeErrorOverlay() {
  var overlay = document.getElementById(OVERLAY_ID);

  if (overlay) {
    overlay.remove();
  }
}

function createErrorOverlay(data) {
  var overlay = document.createElement('div');
  overlay.id = OVERLAY_ID; // html encode message and stack trace

  var message = document.createElement('div');
  var stackTrace = document.createElement('pre');
  message.innerText = data.error.message;
  stackTrace.innerText = data.error.stack;
  overlay.innerHTML = '<div style="background: black; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; opacity: 0.85; font-family: Menlo, Consolas, monospace; z-index: 9999;">' + '<span style="background: red; padding: 2px 4px; border-radius: 2px;">ERROR</span>' + '<span style="top: 2px; margin-left: 5px; position: relative;">🚨</span>' + '<div style="font-size: 18px; font-weight: bold; margin-top: 20px;">' + message.innerHTML + '</div>' + '<pre>' + stackTrace.innerHTML + '</pre>' + '</div>';
  return overlay;
}

function getParents(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return [];
  }

  var parents = [];
  var k, d, dep;

  for (k in modules) {
    for (d in modules[k][1]) {
      dep = modules[k][1][d];

      if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) {
        parents.push(k);
      }
    }
  }

  if (bundle.parent) {
    parents = parents.concat(getParents(bundle.parent, id));
  }

  return parents;
}

function hmrApply(bundle, asset) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (modules[asset.id] || !bundle.parent) {
    var fn = new Function('require', 'module', 'exports', asset.generated.js);
    asset.isNew = !modules[asset.id];
    modules[asset.id] = [fn, asset.deps];
  } else if (bundle.parent) {
    hmrApply(bundle.parent, asset);
  }
}

function hmrAcceptCheck(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (!modules[id] && bundle.parent) {
    return hmrAcceptCheck(bundle.parent, id);
  }

  if (checkedAssets[id]) {
    return;
  }

  checkedAssets[id] = true;
  var cached = bundle.cache[id];
  assetsToAccept.push([bundle, id]);

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    return true;
  }

  return getParents(global.parcelRequire, id).some(function (id) {
    return hmrAcceptCheck(global.parcelRequire, id);
  });
}

function hmrAcceptRun(bundle, id) {
  var cached = bundle.cache[id];
  bundle.hotData = {};

  if (cached) {
    cached.hot.data = bundle.hotData;
  }

  if (cached && cached.hot && cached.hot._disposeCallbacks.length) {
    cached.hot._disposeCallbacks.forEach(function (cb) {
      cb(bundle.hotData);
    });
  }

  delete bundle.cache[id];
  bundle(id);
  cached = bundle.cache[id];

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    cached.hot._acceptCallbacks.forEach(function (cb) {
      cb();
    });

    return true;
  }
}
},{}],"node_modules/parcel-bundler/src/builtins/bundle-loader.js":[function(require,module,exports) {
var getBundleURL = require('./bundle-url').getBundleURL;

function loadBundlesLazy(bundles) {
  if (!Array.isArray(bundles)) {
    bundles = [bundles];
  }

  var id = bundles[bundles.length - 1];

  try {
    return Promise.resolve(require(id));
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND') {
      return new LazyPromise(function (resolve, reject) {
        loadBundles(bundles.slice(0, -1)).then(function () {
          return require(id);
        }).then(resolve, reject);
      });
    }

    throw err;
  }
}

function loadBundles(bundles) {
  return Promise.all(bundles.map(loadBundle));
}

var bundleLoaders = {};

function registerBundleLoader(type, loader) {
  bundleLoaders[type] = loader;
}

module.exports = exports = loadBundlesLazy;
exports.load = loadBundles;
exports.register = registerBundleLoader;
var bundles = {};

function loadBundle(bundle) {
  var id;

  if (Array.isArray(bundle)) {
    id = bundle[1];
    bundle = bundle[0];
  }

  if (bundles[bundle]) {
    return bundles[bundle];
  }

  var type = (bundle.substring(bundle.lastIndexOf('.') + 1, bundle.length) || bundle).toLowerCase();
  var bundleLoader = bundleLoaders[type];

  if (bundleLoader) {
    return bundles[bundle] = bundleLoader(getBundleURL() + bundle).then(function (resolved) {
      if (resolved) {
        module.bundle.register(id, resolved);
      }

      return resolved;
    }).catch(function (e) {
      delete bundles[bundle];
      throw e;
    });
  }
}

function LazyPromise(executor) {
  this.executor = executor;
  this.promise = null;
}

LazyPromise.prototype.then = function (onSuccess, onError) {
  if (this.promise === null) this.promise = new Promise(this.executor);
  return this.promise.then(onSuccess, onError);
};

LazyPromise.prototype.catch = function (onError) {
  if (this.promise === null) this.promise = new Promise(this.executor);
  return this.promise.catch(onError);
};
},{"./bundle-url":"node_modules/parcel-bundler/src/builtins/bundle-url.js"}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline15.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b = __cargo_web_snippet_614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b;

function __cargo_web_snippet_614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.error;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline153.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_c26ddf75f581148e029dfcd95c037bb50d502e43 = __cargo_web_snippet_c26ddf75f581148e029dfcd95c037bb50d502e43;

function __cargo_web_snippet_c26ddf75f581148e029dfcd95c037bb50d502e43(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.value = $1;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline156.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_352943ae98b2eeb817e36305c3531d61c7e1a52b = __cargo_web_snippet_352943ae98b2eeb817e36305c3531d61c7e1a52b;

function __cargo_web_snippet_352943ae98b2eeb817e36305c3531d61c7e1a52b(Module, $0) {
  var o = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return o instanceof Element | 0;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline16.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_b06dde4acf09433b5190a4b001259fe5d4abcbc2 = __cargo_web_snippet_b06dde4acf09433b5190a4b001259fe5d4abcbc2;

function __cargo_web_snippet_b06dde4acf09433b5190a4b001259fe5d4abcbc2(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.success;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline192.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_bb618d13cbb219642bd219af99ee1519e5658d77 = __cargo_web_snippet_bb618d13cbb219642bd219af99ee1519e5658d77;

function __cargo_web_snippet_bb618d13cbb219642bd219af99ee1519e5658d77(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.classList;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline194.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_690311d2f9134ac0983620c38a9e6460d4165607 = __cargo_web_snippet_690311d2f9134ac0983620c38a9e6460d4165607;

function __cargo_web_snippet_690311d2f9134ac0983620c38a9e6460d4165607(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.nextSibling;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline23.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_ab05f53189dacccf2d365ad26daa407d4f7abea9 = __cargo_web_snippet_ab05f53189dacccf2d365ad26daa407d4f7abea9;

function __cargo_web_snippet_ab05f53189dacccf2d365ad26daa407d4f7abea9(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.value;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline293.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_ec62bad51093fd25faa38be3170e100862e191f3 = __cargo_web_snippet_ec62bad51093fd25faa38be3170e100862e191f3;

function __cargo_web_snippet_ec62bad51093fd25faa38be3170e100862e191f3(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.remove($1);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline294.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_8a049af1e4867892fca647811a9472e4c5832053 = __cargo_web_snippet_8a049af1e4867892fca647811a9472e4c5832053;

function __cargo_web_snippet_8a049af1e4867892fca647811a9472e4c5832053(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.add($1);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline318.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_ff5103e6cc179d13b4c7a785bdce2708fd559fc0 = __cargo_web_snippet_ff5103e6cc179d13b4c7a785bdce2708fd559fc0;

function __cargo_web_snippet_ff5103e6cc179d13b4c7a785bdce2708fd559fc0(Module, $0) {
  Module.STDWEB_PRIVATE.tmp = Module.STDWEB_PRIVATE.to_js($0);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline432.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_906f13b1e97c3e6e6996c62d7584c4917315426d = __cargo_web_snippet_906f13b1e97c3e6e6996c62d7584c4917315426d;

function __cargo_web_snippet_906f13b1e97c3e6e6996c62d7584c4917315426d(Module, $0) {
  var o = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return (o instanceof MouseEvent && o.type === "click") | 0;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline499.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.wasm_bindgen_initialize = wasm_bindgen_initialize;

function wasm_bindgen_initialize(memory, table, alloc, free) {
  var Module = {};
  Module.web_malloc = alloc;
  Module.web_free = free;
  Module.web_table = table;
  Object.defineProperty(Module, "HEAP8", {
    get: function get() {
      return new Int8Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAP16", {
    get: function get() {
      return new Int16Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAP32", {
    get: function get() {
      return new Int32Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAPU8", {
    get: function get() {
      return new Uint8Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAPU16", {
    get: function get() {
      return new Uint16Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAPU32", {
    get: function get() {
      return new Uint32Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAPF32", {
    get: function get() {
      return new Float32Array(memory.buffer);
    }
  });
  Object.defineProperty(Module, "HEAPF64", {
    get: function get() {
      return new Float64Array(memory.buffer);
    }
  });
  return Module;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline519.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_8545f3ba2883a49a2afd23c48c5d24ef3f9b0071 = __cargo_web_snippet_8545f3ba2883a49a2afd23c48c5d24ef3f9b0071;

function __cargo_web_snippet_8545f3ba2883a49a2afd23c48c5d24ef3f9b0071(Module, $0) {
  var o = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return o instanceof HTMLTextAreaElement | 0;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline522.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_cb392b71162553130760deeb3964fa828c078f74 = __cargo_web_snippet_cb392b71162553130760deeb3964fa828c078f74;

function __cargo_web_snippet_cb392b71162553130760deeb3964fa828c078f74(Module, $0) {
  var o = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return o instanceof HTMLInputElement | 0;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline534.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_85b9ecbdb8513465b790546acfd0cd530441b8a4 = __cargo_web_snippet_85b9ecbdb8513465b790546acfd0cd530441b8a4;

function __cargo_web_snippet_85b9ecbdb8513465b790546acfd0cd530441b8a4(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $0.stopPropagation();
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline596.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_80d6d56760c65e49b7be8b6b01c1ea861b046bf0 = __cargo_web_snippet_80d6d56760c65e49b7be8b6b01c1ea861b046bf0;

function __cargo_web_snippet_80d6d56760c65e49b7be8b6b01c1ea861b046bf0(Module, $0) {
  Module.STDWEB_PRIVATE.decrement_refcount($0);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline598.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_9f22d4ca7bc938409787341b7db181f8dd41e6df = __cargo_web_snippet_9f22d4ca7bc938409787341b7db181f8dd41e6df;

function __cargo_web_snippet_9f22d4ca7bc938409787341b7db181f8dd41e6df(Module, $0) {
  Module.STDWEB_PRIVATE.increment_refcount($0);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline661.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_0e54fd9c163fcf648ce0a395fde4500fd167a40b = __cargo_web_snippet_0e54fd9c163fcf648ce0a395fde4500fd167a40b;

function __cargo_web_snippet_0e54fd9c163fcf648ce0a395fde4500fd167a40b(Module, $0) {
  var r = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return r instanceof DOMException && r.name === "InvalidCharacterError";
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline665.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_7c8dfab835dc8a552cd9d67f27d26624590e052c = __cargo_web_snippet_7c8dfab835dc8a552cd9d67f27d26624590e052c;

function __cargo_web_snippet_7c8dfab835dc8a552cd9d67f27d26624590e052c(Module, $0) {
  var r = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return r instanceof DOMException && r.name === "SyntaxError";
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline667.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_de2896a7ccf316486788a4d0bc433c25d2f1a12b = __cargo_web_snippet_de2896a7ccf316486788a4d0bc433c25d2f1a12b;

function __cargo_web_snippet_de2896a7ccf316486788a4d0bc433c25d2f1a12b(Module, $0) {
  var r = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return r instanceof DOMException && r.name === "NotFoundError";
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline670.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_c023351d5bff43ef3dd317b499821cd4e71492f0 = __cargo_web_snippet_c023351d5bff43ef3dd317b499821cd4e71492f0;

function __cargo_web_snippet_c023351d5bff43ef3dd317b499821cd4e71492f0(Module, $0) {
  var r = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return r instanceof DOMException && r.name === "HierarchyRequestError";
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline695.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_99c4eefdc8d4cc724135163b8c8665a1f3de99e4 = __cargo_web_snippet_99c4eefdc8d4cc724135163b8c8665a1f3de99e4;

function __cargo_web_snippet_99c4eefdc8d4cc724135163b8c8665a1f3de99e4(Module, $0, $1, $2, $3) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  $3 = Module.STDWEB_PRIVATE.to_js($3);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    var listener = $1;
    $2.addEventListener($3, listener);
    return listener;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline696.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_f750c7bda400081b4d7209f43f9d59214d39f6ea = __cargo_web_snippet_f750c7bda400081b4d7209f43f9d59214d39f6ea;

function __cargo_web_snippet_f750c7bda400081b4d7209f43f9d59214d39f6ea(Module, $0, $1, $2) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  var listener = $0;
  $1.removeEventListener($2, listener);
  listener.drop();
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline805.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_a152e8d0e8fac5476f30c1d19e4ab217dbcba73d = __cargo_web_snippet_a152e8d0e8fac5476f30c1d19e4ab217dbcba73d;

function __cargo_web_snippet_a152e8d0e8fac5476f30c1d19e4ab217dbcba73d(Module, $0, $1, $2) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    try {
      return {
        value: function () {
          return $1.querySelector($2);
        }(),
        success: true
      };
    } catch (error) {
      return {
        error: error,
        success: false
      };
    }
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline840.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_afafe9a462a05084fec65cacc7d6598e145ff3e3 = __cargo_web_snippet_afafe9a462a05084fec65cacc7d6598e145ff3e3;

function __cargo_web_snippet_afafe9a462a05084fec65cacc7d6598e145ff3e3(Module, $0, $1, $2) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.createTextNode($2);
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline848.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_91749aeb589cd0f9b17cbc01b2872ba709817982 = __cargo_web_snippet_91749aeb589cd0f9b17cbc01b2872ba709817982;

function __cargo_web_snippet_91749aeb589cd0f9b17cbc01b2872ba709817982(Module, $0, $1, $2) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    try {
      return {
        value: function () {
          return $1.createElement($2);
        }(),
        success: true
      };
    } catch (error) {
      return {
        error: error,
        success: false
      };
    }
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline850.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_6fcce0aae651e2d748e085ff1f800f87625ff8c8 = __cargo_web_snippet_6fcce0aae651e2d748e085ff1f800f87625ff8c8;

function __cargo_web_snippet_6fcce0aae651e2d748e085ff1f800f87625ff8c8(Module, $0) {
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return document;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline852.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_e9638d6405ab65f78daf4a5af9c9de14ecf1e2ec = __cargo_web_snippet_e9638d6405ab65f78daf4a5af9c9de14ecf1e2ec;

function __cargo_web_snippet_e9638d6405ab65f78daf4a5af9c9de14ecf1e2ec(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  Module.STDWEB_PRIVATE.unregister_raw_value($0);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline854.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_0aced9e2351ced72f1ff99645a129132b16c0d3c = __cargo_web_snippet_0aced9e2351ced72f1ff99645a129132b16c0d3c;

function __cargo_web_snippet_0aced9e2351ced72f1ff99645a129132b16c0d3c(Module, $0) {
  var value = Module.STDWEB_PRIVATE.get_raw_value($0);
  return Module.STDWEB_PRIVATE.register_raw_value(value);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline855.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_72fc447820458c720c68d0d8e078ede631edd723 = __cargo_web_snippet_72fc447820458c720c68d0d8e078ede631edd723;

function __cargo_web_snippet_72fc447820458c720c68d0d8e078ede631edd723(Module, $0, $1, $2) {
  console.error('Panic location:', Module.STDWEB_PRIVATE.to_js_string($0, $1) + ':' + $2);
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline856.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_97495987af1720d8a9a923fa4683a7b683e3acd6 = __cargo_web_snippet_97495987af1720d8a9a923fa4683a7b683e3acd6;

function __cargo_web_snippet_97495987af1720d8a9a923fa4683a7b683e3acd6(Module, $0, $1) {
  console.error('Panic error message:', Module.STDWEB_PRIVATE.to_js_string($0, $1));
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline857.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_dc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf = __cargo_web_snippet_dc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf;

function __cargo_web_snippet_dc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf(Module) {
  console.error('Encountered a panic!');
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline858.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_1c30acb32a1994a07c75e804ae9855b43f191d63 = __cargo_web_snippet_1c30acb32a1994a07c75e804ae9855b43f191d63;

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function __cargo_web_snippet_1c30acb32a1994a07c75e804ae9855b43f191d63(Module) {
  Module.STDWEB_PRIVATE = {};

  Module.STDWEB_PRIVATE.to_utf8 = function to_utf8(str, addr) {
    var HEAPU8 = Module.HEAPU8;

    for (var i = 0; i < str.length; ++i) {
      var u = str.charCodeAt(i);

      if (u >= 0xD800 && u <= 0xDFFF) {
        u = 0x10000 + ((u & 0x3FF) << 10) | str.charCodeAt(++i) & 0x3FF;
      }

      if (u <= 0x7F) {
        HEAPU8[addr++] = u;
      } else if (u <= 0x7FF) {
        HEAPU8[addr++] = 0xC0 | u >> 6;
        HEAPU8[addr++] = 0x80 | u & 63;
      } else if (u <= 0xFFFF) {
        HEAPU8[addr++] = 0xE0 | u >> 12;
        HEAPU8[addr++] = 0x80 | u >> 6 & 63;
        HEAPU8[addr++] = 0x80 | u & 63;
      } else if (u <= 0x1FFFFF) {
        HEAPU8[addr++] = 0xF0 | u >> 18;
        HEAPU8[addr++] = 0x80 | u >> 12 & 63;
        HEAPU8[addr++] = 0x80 | u >> 6 & 63;
        HEAPU8[addr++] = 0x80 | u & 63;
      } else if (u <= 0x3FFFFFF) {
        HEAPU8[addr++] = 0xF8 | u >> 24;
        HEAPU8[addr++] = 0x80 | u >> 18 & 63;
        HEAPU8[addr++] = 0x80 | u >> 12 & 63;
        HEAPU8[addr++] = 0x80 | u >> 6 & 63;
        HEAPU8[addr++] = 0x80 | u & 63;
      } else {
        HEAPU8[addr++] = 0xFC | u >> 30;
        HEAPU8[addr++] = 0x80 | u >> 24 & 63;
        HEAPU8[addr++] = 0x80 | u >> 18 & 63;
        HEAPU8[addr++] = 0x80 | u >> 12 & 63;
        HEAPU8[addr++] = 0x80 | u >> 6 & 63;
        HEAPU8[addr++] = 0x80 | u & 63;
      }
    }
  };

  Module.STDWEB_PRIVATE.noop = function () {};

  Module.STDWEB_PRIVATE.to_js = function to_js(address) {
    var kind = Module.HEAPU8[address + 12];

    if (kind === 0) {
      return undefined;
    } else if (kind === 1) {
      return null;
    } else if (kind === 2) {
      return Module.HEAP32[address / 4];
    } else if (kind === 3) {
      return Module.HEAPF64[address / 8];
    } else if (kind === 4) {
      var pointer = Module.HEAPU32[address / 4];
      var length = Module.HEAPU32[(address + 4) / 4];
      return Module.STDWEB_PRIVATE.to_js_string(pointer, length);
    } else if (kind === 5) {
      return false;
    } else if (kind === 6) {
      return true;
    } else if (kind === 7) {
      var pointer = Module.STDWEB_PRIVATE.arena + Module.HEAPU32[address / 4];
      var length = Module.HEAPU32[(address + 4) / 4];
      var _output = [];

      for (var i = 0; i < length; ++i) {
        _output.push(Module.STDWEB_PRIVATE.to_js(pointer + i * 16));
      }

      return _output;
    } else if (kind === 8) {
      var arena = Module.STDWEB_PRIVATE.arena;
      var value_array_pointer = arena + Module.HEAPU32[address / 4];
      var length = Module.HEAPU32[(address + 4) / 4];
      var key_array_pointer = arena + Module.HEAPU32[(address + 8) / 4];
      var _output = {};

      for (var i = 0; i < length; ++i) {
        var key_pointer = Module.HEAPU32[(key_array_pointer + i * 8) / 4];
        var key_length = Module.HEAPU32[(key_array_pointer + 4 + i * 8) / 4];
        var key = Module.STDWEB_PRIVATE.to_js_string(key_pointer, key_length);
        var value = Module.STDWEB_PRIVATE.to_js(value_array_pointer + i * 16);
        _output[key] = value;
      }

      return _output;
    } else if (kind === 9) {
      return Module.STDWEB_PRIVATE.acquire_js_reference(Module.HEAP32[address / 4]);
    } else if (kind === 10 || kind === 12 || kind === 13) {
      var adapter_pointer = Module.HEAPU32[address / 4];
      var pointer = Module.HEAPU32[(address + 4) / 4];
      var deallocator_pointer = Module.HEAPU32[(address + 8) / 4];
      var num_ongoing_calls = 0;
      var drop_queued = false;

      var _output = function output() {
        if (pointer === 0 || drop_queued === true) {
          if (kind === 10) {
            throw new ReferenceError("Already dropped Rust function called!");
          } else if (kind === 12) {
            throw new ReferenceError("Already dropped FnMut function called!");
          } else {
            throw new ReferenceError("Already called or dropped FnOnce function called!");
          }
        }

        var function_pointer = pointer;

        if (kind === 13) {
          _output.drop = Module.STDWEB_PRIVATE.noop;
          pointer = 0;
        }

        if (num_ongoing_calls !== 0) {
          if (kind === 12 || kind === 13) {
            throw new ReferenceError("FnMut function called multiple times concurrently!");
          }
        }

        var args = Module.STDWEB_PRIVATE.alloc(16);
        Module.STDWEB_PRIVATE.serialize_array(args, arguments);

        try {
          num_ongoing_calls += 1;
          Module.STDWEB_PRIVATE.dyncall("vii", adapter_pointer, [function_pointer, args]);
          var result = Module.STDWEB_PRIVATE.tmp;
          Module.STDWEB_PRIVATE.tmp = null;
        } finally {
          num_ongoing_calls -= 1;
        }

        if (drop_queued === true && num_ongoing_calls === 0) {
          _output.drop();
        }

        return result;
      };

      _output.drop = function () {
        if (num_ongoing_calls !== 0) {
          drop_queued = true;
          return;
        }

        _output.drop = Module.STDWEB_PRIVATE.noop;
        var function_pointer = pointer;
        pointer = 0;

        if (function_pointer != 0) {
          Module.STDWEB_PRIVATE.dyncall("vi", deallocator_pointer, [function_pointer]);
        }
      };

      return _output;
    } else if (kind === 14) {
      var pointer = Module.HEAPU32[address / 4];
      var length = Module.HEAPU32[(address + 4) / 4];
      var array_kind = Module.HEAPU32[(address + 8) / 4];
      var pointer_end = pointer + length;

      switch (array_kind) {
        case 0:
          return Module.HEAPU8.subarray(pointer, pointer_end);

        case 1:
          return Module.HEAP8.subarray(pointer, pointer_end);

        case 2:
          return Module.HEAPU16.subarray(pointer, pointer_end);

        case 3:
          return Module.HEAP16.subarray(pointer, pointer_end);

        case 4:
          return Module.HEAPU32.subarray(pointer, pointer_end);

        case 5:
          return Module.HEAP32.subarray(pointer, pointer_end);

        case 6:
          return Module.HEAPF32.subarray(pointer, pointer_end);

        case 7:
          return Module.HEAPF64.subarray(pointer, pointer_end);
      }
    } else if (kind === 15) {
      return Module.STDWEB_PRIVATE.get_raw_value(Module.HEAPU32[address / 4]);
    }
  };

  Module.STDWEB_PRIVATE.serialize_object = function serialize_object(address, value) {
    var keys = Object.keys(value);
    var length = keys.length;
    var key_array_pointer = Module.STDWEB_PRIVATE.alloc(length * 8);
    var value_array_pointer = Module.STDWEB_PRIVATE.alloc(length * 16);
    Module.HEAPU8[address + 12] = 8;
    Module.HEAPU32[address / 4] = value_array_pointer;
    Module.HEAPU32[(address + 4) / 4] = length;
    Module.HEAPU32[(address + 8) / 4] = key_array_pointer;

    for (var i = 0; i < length; ++i) {
      var key = keys[i];
      var key_address = key_array_pointer + i * 8;
      Module.STDWEB_PRIVATE.to_utf8_string(key_address, key);
      Module.STDWEB_PRIVATE.from_js(value_array_pointer + i * 16, value[key]);
    }
  };

  Module.STDWEB_PRIVATE.serialize_array = function serialize_array(address, value) {
    var length = value.length;
    var pointer = Module.STDWEB_PRIVATE.alloc(length * 16);
    Module.HEAPU8[address + 12] = 7;
    Module.HEAPU32[address / 4] = pointer;
    Module.HEAPU32[(address + 4) / 4] = length;

    for (var i = 0; i < length; ++i) {
      Module.STDWEB_PRIVATE.from_js(pointer + i * 16, value[i]);
    }
  };

  var cachedEncoder = typeof TextEncoder === "function" ? new TextEncoder("utf-8") : (typeof util === "undefined" ? "undefined" : _typeof(util)) === "object" && util && typeof util.TextEncoder === "function" ? new util.TextEncoder("utf-8") : null;

  if (cachedEncoder != null) {
    Module.STDWEB_PRIVATE.to_utf8_string = function to_utf8_string(address, value) {
      var buffer = cachedEncoder.encode(value);
      var length = buffer.length;
      var pointer = 0;

      if (length > 0) {
        pointer = Module.STDWEB_PRIVATE.alloc(length);
        Module.HEAPU8.set(buffer, pointer);
      }

      Module.HEAPU32[address / 4] = pointer;
      Module.HEAPU32[(address + 4) / 4] = length;
    };
  } else {
    Module.STDWEB_PRIVATE.to_utf8_string = function to_utf8_string(address, value) {
      var length = Module.STDWEB_PRIVATE.utf8_len(value);
      var pointer = 0;

      if (length > 0) {
        pointer = Module.STDWEB_PRIVATE.alloc(length);
        Module.STDWEB_PRIVATE.to_utf8(value, pointer);
      }

      Module.HEAPU32[address / 4] = pointer;
      Module.HEAPU32[(address + 4) / 4] = length;
    };
  }

  Module.STDWEB_PRIVATE.from_js = function from_js(address, value) {
    var kind = Object.prototype.toString.call(value);

    if (kind === "[object String]") {
      Module.HEAPU8[address + 12] = 4;
      Module.STDWEB_PRIVATE.to_utf8_string(address, value);
    } else if (kind === "[object Number]") {
      if (value === (value | 0)) {
        Module.HEAPU8[address + 12] = 2;
        Module.HEAP32[address / 4] = value;
      } else {
        Module.HEAPU8[address + 12] = 3;
        Module.HEAPF64[address / 8] = value;
      }
    } else if (value === null) {
      Module.HEAPU8[address + 12] = 1;
    } else if (value === undefined) {
      Module.HEAPU8[address + 12] = 0;
    } else if (value === false) {
      Module.HEAPU8[address + 12] = 5;
    } else if (value === true) {
      Module.HEAPU8[address + 12] = 6;
    } else if (kind === "[object Symbol]") {
      var id = Module.STDWEB_PRIVATE.register_raw_value(value);
      Module.HEAPU8[address + 12] = 15;
      Module.HEAP32[address / 4] = id;
    } else {
      var refid = Module.STDWEB_PRIVATE.acquire_rust_reference(value);
      Module.HEAPU8[address + 12] = 9;
      Module.HEAP32[address / 4] = refid;
    }
  };

  var cachedDecoder = typeof TextDecoder === "function" ? new TextDecoder("utf-8") : (typeof util === "undefined" ? "undefined" : _typeof(util)) === "object" && util && typeof util.TextDecoder === "function" ? new util.TextDecoder("utf-8") : null;

  if (cachedDecoder != null) {
    Module.STDWEB_PRIVATE.to_js_string = function to_js_string(index, length) {
      return cachedDecoder.decode(Module.HEAPU8.subarray(index, index + length));
    };
  } else {
    Module.STDWEB_PRIVATE.to_js_string = function to_js_string(index, length) {
      var HEAPU8 = Module.HEAPU8;
      index = index | 0;
      length = length | 0;
      var end = (index | 0) + (length | 0);
      var output = "";

      while (index < end) {
        var x = HEAPU8[index++];

        if (x < 128) {
          output += String.fromCharCode(x);
          continue;
        }

        var init = x & 0x7F >> 2;
        var y = 0;

        if (index < end) {
          y = HEAPU8[index++];
        }

        var ch = init << 6 | y & 63;

        if (x >= 0xE0) {
          var z = 0;

          if (index < end) {
            z = HEAPU8[index++];
          }

          var y_z = (y & 63) << 6 | z & 63;
          ch = init << 12 | y_z;

          if (x >= 0xF0) {
            var w = 0;

            if (index < end) {
              w = HEAPU8[index++];
            }

            ch = (init & 7) << 18 | (y_z << 6 | w & 63);
            output += String.fromCharCode(0xD7C0 + (ch >> 10));
            ch = 0xDC00 + (ch & 0x3FF);
          }
        }

        output += String.fromCharCode(ch);
        continue;
      }

      return output;
    };
  }

  Module.STDWEB_PRIVATE.id_to_ref_map = {};
  Module.STDWEB_PRIVATE.id_to_refcount_map = {};
  Module.STDWEB_PRIVATE.ref_to_id_map = new WeakMap();
  Module.STDWEB_PRIVATE.ref_to_id_map_fallback = new Map();
  Module.STDWEB_PRIVATE.last_refid = 1;
  Module.STDWEB_PRIVATE.id_to_raw_value_map = {};
  Module.STDWEB_PRIVATE.last_raw_value_id = 1;

  Module.STDWEB_PRIVATE.acquire_rust_reference = function (reference) {
    if (reference === undefined || reference === null) {
      return 0;
    }

    var id_to_refcount_map = Module.STDWEB_PRIVATE.id_to_refcount_map;
    var id_to_ref_map = Module.STDWEB_PRIVATE.id_to_ref_map;
    var ref_to_id_map = Module.STDWEB_PRIVATE.ref_to_id_map;
    var ref_to_id_map_fallback = Module.STDWEB_PRIVATE.ref_to_id_map_fallback;
    var refid = ref_to_id_map.get(reference);

    if (refid === undefined) {
      refid = ref_to_id_map_fallback.get(reference);
    }

    if (refid === undefined) {
      refid = Module.STDWEB_PRIVATE.last_refid++;

      try {
        ref_to_id_map.set(reference, refid);
      } catch (e) {
        ref_to_id_map_fallback.set(reference, refid);
      }
    }

    if (refid in id_to_ref_map) {
      id_to_refcount_map[refid]++;
    } else {
      id_to_ref_map[refid] = reference;
      id_to_refcount_map[refid] = 1;
    }

    return refid;
  };

  Module.STDWEB_PRIVATE.acquire_js_reference = function (refid) {
    return Module.STDWEB_PRIVATE.id_to_ref_map[refid];
  };

  Module.STDWEB_PRIVATE.increment_refcount = function (refid) {
    Module.STDWEB_PRIVATE.id_to_refcount_map[refid]++;
  };

  Module.STDWEB_PRIVATE.decrement_refcount = function (refid) {
    var id_to_refcount_map = Module.STDWEB_PRIVATE.id_to_refcount_map;

    if (0 == --id_to_refcount_map[refid]) {
      var id_to_ref_map = Module.STDWEB_PRIVATE.id_to_ref_map;
      var ref_to_id_map_fallback = Module.STDWEB_PRIVATE.ref_to_id_map_fallback;
      var reference = id_to_ref_map[refid];
      delete id_to_ref_map[refid];
      delete id_to_refcount_map[refid];
      ref_to_id_map_fallback.delete(reference);
    }
  };

  Module.STDWEB_PRIVATE.register_raw_value = function (value) {
    var id = Module.STDWEB_PRIVATE.last_raw_value_id++;
    Module.STDWEB_PRIVATE.id_to_raw_value_map[id] = value;
    return id;
  };

  Module.STDWEB_PRIVATE.unregister_raw_value = function (id) {
    delete Module.STDWEB_PRIVATE.id_to_raw_value_map[id];
  };

  Module.STDWEB_PRIVATE.get_raw_value = function (id) {
    return Module.STDWEB_PRIVATE.id_to_raw_value_map[id];
  };

  Module.STDWEB_PRIVATE.alloc = function alloc(size) {
    return Module.web_malloc(size);
  };

  Module.STDWEB_PRIVATE.dyncall = function (signature, ptr, args) {
    return Module.web_table.get(ptr).apply(null, args);
  };

  Module.STDWEB_PRIVATE.utf8_len = function utf8_len(str) {
    var len = 0;

    for (var i = 0; i < str.length; ++i) {
      var u = str.charCodeAt(i);

      if (u >= 0xD800 && u <= 0xDFFF) {
        u = 0x10000 + ((u & 0x3FF) << 10) | str.charCodeAt(++i) & 0x3FF;
      }

      if (u <= 0x7F) {
        ++len;
      } else if (u <= 0x7FF) {
        len += 2;
      } else if (u <= 0xFFFF) {
        len += 3;
      } else if (u <= 0x1FFFFF) {
        len += 4;
      } else if (u <= 0x3FFFFFF) {
        len += 5;
      } else {
        len += 6;
      }
    }

    return len;
  };

  Module.STDWEB_PRIVATE.prepare_any_arg = function (value) {
    var arg = Module.STDWEB_PRIVATE.alloc(16);
    Module.STDWEB_PRIVATE.from_js(arg, value);
    return arg;
  };

  Module.STDWEB_PRIVATE.acquire_tmp = function (dummy) {
    var value = Module.STDWEB_PRIVATE.tmp;
    Module.STDWEB_PRIVATE.tmp = null;
    return value;
  };
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline887.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_351b27505bc97d861c3914c20421b6277babb53b = __cargo_web_snippet_351b27505bc97d861c3914c20421b6277babb53b;

function __cargo_web_snippet_351b27505bc97d861c3914c20421b6277babb53b(Module, $0) {
  var o = Module.STDWEB_PRIVATE.acquire_js_reference($0);
  return o instanceof Node | 0;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline902.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_08a3b15e1358700ac92bc556f9e9b8af660fc2c7 = __cargo_web_snippet_08a3b15e1358700ac92bc556f9e9b8af660fc2c7;

function __cargo_web_snippet_08a3b15e1358700ac92bc556f9e9b8af660fc2c7(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.nodeValue = $1;
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline907.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_f03767d5868baf486b51c1e3988d0ce100e850ca = __cargo_web_snippet_f03767d5868baf486b51c1e3988d0ce100e850ca;

function __cargo_web_snippet_f03767d5868baf486b51c1e3988d0ce100e850ca(Module, $0, $1) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    return $1.lastChild;
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline917.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_46518012593da937dd5f35c2fc1c5e1dcade260b = __cargo_web_snippet_46518012593da937dd5f35c2fc1c5e1dcade260b;

function __cargo_web_snippet_46518012593da937dd5f35c2fc1c5e1dcade260b(Module, $0, $1, $2, $3) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  $3 = Module.STDWEB_PRIVATE.to_js($3);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    try {
      return {
        value: function () {
          return $1.insertBefore($2, $3);
        }(),
        success: true
      };
    } catch (error) {
      return {
        error: error,
        success: false
      };
    }
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline923.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_cd41a77d0178ae27c833ef2950e5f1a48a1455c1 = __cargo_web_snippet_cd41a77d0178ae27c833ef2950e5f1a48a1455c1;

function __cargo_web_snippet_cd41a77d0178ae27c833ef2950e5f1a48a1455c1(Module, $0, $1, $2) {
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  Module.STDWEB_PRIVATE.from_js($0, function () {
    try {
      return {
        value: function () {
          return $1.removeChild($2);
        }(),
        success: true
      };
    } catch (error) {
      return {
        error: error,
        success: false
      };
    }
  }());
}
},{}],"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline924.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_e741b9d9071097746386b2c2ec044a2bc73e688c = __cargo_web_snippet_e741b9d9071097746386b2c2ec044a2bc73e688c;

function __cargo_web_snippet_e741b9d9071097746386b2c2ec044a2bc73e688c(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.appendChild($1);
}
},{}],"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline0.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_4fd31c9e56d40b8642cf9e6f96fd6b570f355cea = __cargo_web_snippet_4fd31c9e56d40b8642cf9e6f96fd6b570f355cea;

function __cargo_web_snippet_4fd31c9e56d40b8642cf9e6f96fd6b570f355cea(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  console.error($0);
}
},{}],"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline1.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_114b518968fda2247f8d0d6ad5a226d35aa55986 = __cargo_web_snippet_114b518968fda2247f8d0d6ad5a226d35aa55986;

function __cargo_web_snippet_114b518968fda2247f8d0d6ad5a226d35aa55986(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  console.warn($0);
}
},{}],"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline2.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_c5c1b47195f246fcd2672c546e8c4d526e328687 = __cargo_web_snippet_c5c1b47195f246fcd2672c546e8c4d526e328687;

function __cargo_web_snippet_c5c1b47195f246fcd2672c546e8c4d526e328687(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  console.info($0);
}
},{}],"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline3.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b = __cargo_web_snippet_6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b;

function __cargo_web_snippet_6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  console.debug($0);
}
},{}],"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline4.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_199d5eb25dfe761687bcd487578eb7e636bd9650 = __cargo_web_snippet_199d5eb25dfe761687bcd487578eb7e636bd9650;

function __cargo_web_snippet_199d5eb25dfe761687bcd487578eb7e636bd9650(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  console.log($0);
}
},{}],"crate/pkg/snippets/yew-55512dcf734c13d9/inline31.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_a1f43b583e011a9bbeae64030b81f677e6c29005 = __cargo_web_snippet_a1f43b583e011a9bbeae64030b81f677e6c29005;

function __cargo_web_snippet_a1f43b583e011a9bbeae64030b81f677e6c29005(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.checked = $1;
}
},{}],"crate/pkg/snippets/yew-55512dcf734c13d9/inline32.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_f6358c198ebcc61c9da370cca2679c0b8bc81a7b = __cargo_web_snippet_f6358c198ebcc61c9da370cca2679c0b8bc81a7b;

function __cargo_web_snippet_f6358c198ebcc61c9da370cca2679c0b8bc81a7b(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.removeAttribute($1);
}
},{}],"crate/pkg/snippets/yew-55512dcf734c13d9/inline33.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_da2febd72f9938d90bc2bf2905643f595b07abd9 = __cargo_web_snippet_da2febd72f9938d90bc2bf2905643f595b07abd9;

function __cargo_web_snippet_da2febd72f9938d90bc2bf2905643f595b07abd9(Module, $0, $1, $2) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $2 = Module.STDWEB_PRIVATE.to_js($2);
  $0.setAttribute($1, $2);
}
},{}],"crate/pkg/snippets/yew-55512dcf734c13d9/inline34.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_6a77b2f2accec26fefbfa0d864061d26f40f8f6f = __cargo_web_snippet_6a77b2f2accec26fefbfa0d864061d26f40f8f6f;

function __cargo_web_snippet_6a77b2f2accec26fefbfa0d864061d26f40f8f6f(Module, $0) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $0.type = "";
}
},{}],"crate/pkg/snippets/yew-55512dcf734c13d9/inline35.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.__cargo_web_snippet_0da47658267a7497de743e1b0892f992ba6ca6ef = __cargo_web_snippet_0da47658267a7497de743e1b0892f992ba6ca6ef;

function __cargo_web_snippet_0da47658267a7497de743e1b0892f992ba6ca6ef(Module, $0, $1) {
  $0 = Module.STDWEB_PRIVATE.to_js($0);
  $1 = Module.STDWEB_PRIVATE.to_js($1);
  $0.type = $1;
}
},{}],"node_modules/parcel-bundler/src/builtins/_empty.js":[function(require,module,exports) {

},{}],"node_modules/parcel-plugin-wasm.rs/wasm-loader.js":[function(require,module,exports) {
var global = arguments[3];
var __dirname = "/media/extraymond/storages/git/rusty-app/node_modules/parcel-plugin-wasm.rs";
"use strict";

var _inline = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline15.js");

var _inline2 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline153.js");

var _inline3 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline156.js");

var _inline4 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline16.js");

var _inline5 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline192.js");

var _inline6 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline194.js");

var _inline7 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline23.js");

var _inline8 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline293.js");

var _inline9 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline294.js");

var _inline10 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline318.js");

var _inline11 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline432.js");

var _inline12 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline499.js");

var _inline13 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline519.js");

var _inline14 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline522.js");

var _inline15 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline534.js");

var _inline16 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline596.js");

var _inline17 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline598.js");

var _inline18 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline661.js");

var _inline19 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline665.js");

var _inline20 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline667.js");

var _inline21 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline670.js");

var _inline22 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline695.js");

var _inline23 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline696.js");

var _inline24 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline805.js");

var _inline25 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline840.js");

var _inline26 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline848.js");

var _inline27 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline850.js");

var _inline28 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline852.js");

var _inline29 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline854.js");

var _inline30 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline855.js");

var _inline31 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline856.js");

var _inline32 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline857.js");

var _inline33 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline858.js");

var _inline34 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline887.js");

var _inline35 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline902.js");

var _inline36 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline907.js");

var _inline37 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline917.js");

var _inline38 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline923.js");

var _inline39 = require("../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline924.js");

var _inline40 = require("../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline0.js");

var _inline41 = require("../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline1.js");

var _inline42 = require("../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline2.js");

var _inline43 = require("../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline3.js");

var _inline44 = require("../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline4.js");

var _inline45 = require("../../crate/pkg/snippets/yew-55512dcf734c13d9/inline31.js");

var _inline46 = require("../../crate/pkg/snippets/yew-55512dcf734c13d9/inline32.js");

var _inline47 = require("../../crate/pkg/snippets/yew-55512dcf734c13d9/inline33.js");

var _inline48 = require("../../crate/pkg/snippets/yew-55512dcf734c13d9/inline34.js");

var _inline49 = require("../../crate/pkg/snippets/yew-55512dcf734c13d9/inline35.js");

var wasm;
const __exports = {};

function __wbg_elem_binding0(arg0, arg1) {
  wasm.__wbg_function_table.get(19)(arg0, arg1);
}

const heap = new Array(32);
heap.fill(undefined);
heap.push(undefined, null, true, false);
let heap_next = heap.length;

function addHeapObject(obj) {
  if (heap_next === heap.length) heap.push(heap.length + 1);
  const idx = heap_next;
  heap_next = heap[idx];
  heap[idx] = obj;
  return idx;
}

function __wbg_elem_binding1(arg0, arg1, arg2) {
  wasm.__wbg_function_table.get(25)(arg0, arg1, addHeapObject(arg2));
}

function __wbg_elem_binding2(arg0, arg1, arg2, arg3) {
  wasm.__wbg_function_table.get(11)(arg0, arg1, arg2, arg3);
}

function __wbg_elem_binding3(arg0, arg1, arg2) {
  const ret = wasm.__wbg_function_table.get(15)(arg0, arg1, arg2);

  return ret;
}
/**
*/


__exports.run = function () {
  wasm.run();
};

function getObject(idx) {
  return heap[idx];
}

function dropObject(idx) {
  if (idx < 36) return;
  heap[idx] = heap_next;
  heap_next = idx;
}

function takeObject(idx) {
  const ret = getObject(idx);
  dropObject(idx);
  return ret;
}

function isLikeNone(x) {
  return x === undefined || x === null;
}

function handleError(e) {
  wasm.__wbindgen_exn_store(addHeapObject(e));
}

let cachedTextDecoder = new TextDecoder('utf-8');
let cachegetUint8Memory = null;

function getUint8Memory() {
  if (cachegetUint8Memory === null || cachegetUint8Memory.buffer !== wasm.memory.buffer) {
    cachegetUint8Memory = new Uint8Array(wasm.memory.buffer);
  }

  return cachegetUint8Memory;
}

function getStringFromWasm(ptr, len) {
  return cachedTextDecoder.decode(getUint8Memory().subarray(ptr, ptr + len));
}

let WASM_VECTOR_LEN = 0;
let cachedTextEncoder = new TextEncoder('utf-8');
let passStringToWasm;

if (typeof cachedTextEncoder.encodeInto === 'function') {
  passStringToWasm = function (arg) {
    let size = arg.length;

    let ptr = wasm.__wbindgen_malloc(size);

    let offset = 0;
    {
      const mem = getUint8Memory();

      for (; offset < arg.length; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
      }
    }

    if (offset !== arg.length) {
      arg = arg.slice(offset);
      ptr = wasm.__wbindgen_realloc(ptr, size, size = offset + arg.length * 3);
      const view = getUint8Memory().subarray(ptr + offset, ptr + size);
      const ret = cachedTextEncoder.encodeInto(arg, view);
      offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
  };
} else {
  passStringToWasm = function (arg) {
    let size = arg.length;

    let ptr = wasm.__wbindgen_malloc(size);

    let offset = 0;
    {
      const mem = getUint8Memory();

      for (; offset < arg.length; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
      }
    }

    if (offset !== arg.length) {
      const buf = cachedTextEncoder.encode(arg.slice(offset));
      ptr = wasm.__wbindgen_realloc(ptr, size, size = offset + buf.length);
      getUint8Memory().set(buf, ptr + offset);
      offset += buf.length;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
  };
}

let cachegetInt32Memory = null;

function getInt32Memory() {
  if (cachegetInt32Memory === null || cachegetInt32Memory.buffer !== wasm.memory.buffer) {
    cachegetInt32Memory = new Int32Array(wasm.memory.buffer);
  }

  return cachegetInt32Memory;
}

function debugString(val) {
  // primitive types
  const type = typeof val;

  if (type == 'number' || type == 'boolean' || val == null) {
    return `${val}`;
  }

  if (type == 'string') {
    return `"${val}"`;
  }

  if (type == 'symbol') {
    const description = val.description;

    if (description == null) {
      return 'Symbol';
    } else {
      return `Symbol(${description})`;
    }
  }

  if (type == 'function') {
    const name = val.name;

    if (typeof name == 'string' && name.length > 0) {
      return `Function(${name})`;
    } else {
      return 'Function';
    }
  } // objects


  if (Array.isArray(val)) {
    const length = val.length;
    let debug = '[';

    if (length > 0) {
      debug += debugString(val[0]);
    }

    for (let i = 1; i < length; i++) {
      debug += ', ' + debugString(val[i]);
    }

    debug += ']';
    return debug;
  } // Test for built-in


  const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
  let className;

  if (builtInMatches.length > 1) {
    className = builtInMatches[1];
  } else {
    // Failed to match the standard '[object ClassName]'
    return toString.call(val);
  }

  if (className == 'Object') {
    // we're a user defined class or Object
    // JSON.stringify avoids problems with cycles, and is generally much
    // easier than looping through ownProperties of `val`.
    try {
      return 'Object(' + JSON.stringify(val) + ')';
    } catch (_) {
      return 'Object';
    }
  } // errors


  if (val instanceof Error) {
    return `${val.name}: ${val.message}\n${val.stack}`;
  } // TODO we could test for more things here, like `Set`s and `Map`s.


  return className;
}

__exports.__wbg_cargowebsnippet80d6d56760c65e49b7be8b6b01c1ea861b046bf0_7ec6f0fcb701132f = function (arg0, arg1) {
  const ret = (0, _inline16.__cargo_web_snippet_80d6d56760c65e49b7be8b6b01c1ea861b046bf0)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet9f22d4ca7bc938409787341b7db181f8dd41e6df_1379a66e2ec58736 = function (arg0, arg1) {
  const ret = (0, _inline17.__cargo_web_snippet_9f22d4ca7bc938409787341b7db181f8dd41e6df)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetcb392b71162553130760deeb3964fa828c078f74_d988e0053b916e8e = function (arg0, arg1) {
  const ret = (0, _inline14.__cargo_web_snippet_cb392b71162553130760deeb3964fa828c078f74)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet8545f3ba2883a49a2afd23c48c5d24ef3f9b0071_1a7f074796deed24 = function (arg0, arg1) {
  const ret = (0, _inline13.__cargo_web_snippet_8545f3ba2883a49a2afd23c48c5d24ef3f9b0071)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetc26ddf75f581148e029dfcd95c037bb50d502e43_c2bef511b7847452 = function (arg0, arg1, arg2) {
  const ret = (0, _inline2.__cargo_web_snippet_c26ddf75f581148e029dfcd95c037bb50d502e43)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet0da47658267a7497de743e1b0892f992ba6ca6ef_0aba570773913087 = function (arg0, arg1, arg2) {
  const ret = (0, _inline49.__cargo_web_snippet_0da47658267a7497de743e1b0892f992ba6ca6ef)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet6a77b2f2accec26fefbfa0d864061d26f40f8f6f_6748f802f3e70344 = function (arg0, arg1) {
  const ret = (0, _inline48.__cargo_web_snippet_6a77b2f2accec26fefbfa0d864061d26f40f8f6f)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetcd41a77d0178ae27c833ef2950e5f1a48a1455c1_1f0ed8dbd932c631 = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline38.__cargo_web_snippet_cd41a77d0178ae27c833ef2950e5f1a48a1455c1)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippetb06dde4acf09433b5190a4b001259fe5d4abcbc2_97865628753d6bc0 = function (arg0, arg1, arg2) {
  const ret = (0, _inline4.__cargo_web_snippet_b06dde4acf09433b5190a4b001259fe5d4abcbc2)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b_b8735580a03758ff = function (arg0, arg1, arg2) {
  const ret = (0, _inline.__cargo_web_snippet_614a3dd2adb7e9eac4a0ec6e59d37f87e0521c3b)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippetab05f53189dacccf2d365ad26daa407d4f7abea9_3bf771698c5b339d = function (arg0, arg1, arg2) {
  const ret = (0, _inline7.__cargo_web_snippet_ab05f53189dacccf2d365ad26daa407d4f7abea9)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippetde2896a7ccf316486788a4d0bc433c25d2f1a12b_e6d4db0522b94d56 = function (arg0, arg1) {
  const ret = (0, _inline20.__cargo_web_snippet_de2896a7ccf316486788a4d0bc433c25d2f1a12b)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetda2febd72f9938d90bc2bf2905643f595b07abd9_0b29f38fb612a395 = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline47.__cargo_web_snippet_da2febd72f9938d90bc2bf2905643f595b07abd9)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippetf6358c198ebcc61c9da370cca2679c0b8bc81a7b_b0a8d74a3dbb1007 = function (arg0, arg1, arg2) {
  const ret = (0, _inline46.__cargo_web_snippet_f6358c198ebcc61c9da370cca2679c0b8bc81a7b)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippeta1f43b583e011a9bbeae64030b81f677e6c29005_1cdb3d16b55d23f0 = function (arg0, arg1, arg2) {
  const ret = (0, _inline45.__cargo_web_snippet_a1f43b583e011a9bbeae64030b81f677e6c29005)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet351b27505bc97d861c3914c20421b6277babb53b_bcf0cf78c6ec3fcf = function (arg0, arg1) {
  const ret = (0, _inline34.__cargo_web_snippet_351b27505bc97d861c3914c20421b6277babb53b)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetf03767d5868baf486b51c1e3988d0ce100e850ca_3e1dbc3b1f5b7b3b = function (arg0, arg1, arg2) {
  const ret = (0, _inline36.__cargo_web_snippet_f03767d5868baf486b51c1e3988d0ce100e850ca)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet4fd31c9e56d40b8642cf9e6f96fd6b570f355cea_8a401aade62618ba = function (arg0, arg1) {
  const ret = (0, _inline40.__cargo_web_snippet_4fd31c9e56d40b8642cf9e6f96fd6b570f355cea)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet199d5eb25dfe761687bcd487578eb7e636bd9650_cab2de567628901e = function (arg0, arg1) {
  const ret = (0, _inline44.__cargo_web_snippet_199d5eb25dfe761687bcd487578eb7e636bd9650)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b_2b46a18b54b44834 = function (arg0, arg1) {
  const ret = (0, _inline43.__cargo_web_snippet_6bcfdb0f4808b0b1e8b8b8d2facd39b73ac5018b)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetc5c1b47195f246fcd2672c546e8c4d526e328687_8e9bf2760a8d405c = function (arg0, arg1) {
  const ret = (0, _inline42.__cargo_web_snippet_c5c1b47195f246fcd2672c546e8c4d526e328687)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet114b518968fda2247f8d0d6ad5a226d35aa55986_90291b06311b4650 = function (arg0, arg1) {
  const ret = (0, _inline41.__cargo_web_snippet_114b518968fda2247f8d0d6ad5a226d35aa55986)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet8a049af1e4867892fca647811a9472e4c5832053_97149205cb6db10d = function (arg0, arg1, arg2) {
  const ret = (0, _inline9.__cargo_web_snippet_8a049af1e4867892fca647811a9472e4c5832053)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippetec62bad51093fd25faa38be3170e100862e191f3_8e82e4b5edcec496 = function (arg0, arg1, arg2) {
  const ret = (0, _inline8.__cargo_web_snippet_ec62bad51093fd25faa38be3170e100862e191f3)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbindgen_object_clone_ref = function (arg0) {
  const ret = getObject(arg0);
  return addHeapObject(ret);
};

__exports.__wbg_cargowebsnippetf750c7bda400081b4d7209f43f9d59214d39f6ea_ae7cb4f5c5b41234 = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline23.__cargo_web_snippet_f750c7bda400081b4d7209f43f9d59214d39f6ea)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbindgen_memory = function () {
  const ret = wasm.memory;
  return addHeapObject(ret);
};

__exports.__wbindgen_function_table = function () {
  const ret = wasm.__wbg_function_table;
  return addHeapObject(ret);
};

__exports.__wbg_wasmbindgeninitialize_a48a748cf08ec22f = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline12.wasm_bindgen_initialize)(takeObject(arg0), takeObject(arg1), getObject(arg2), getObject(arg3));
  return addHeapObject(ret);
};

__exports.__wbindgen_object_drop_ref = function (arg0) {
  takeObject(arg0);
};

__exports.__wbindgen_cb_forget = function (arg0) {
  takeObject(arg0);
};

__exports.__wbg_cargowebsnippet1c30acb32a1994a07c75e804ae9855b43f191d63_74dac66dda56bf23 = function (arg0) {
  const ret = (0, _inline33.__cargo_web_snippet_1c30acb32a1994a07c75e804ae9855b43f191d63)(takeObject(arg0));
  return ret;
};

__exports.__wbg_cargowebsnippetdc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf_9df7357276751689 = function (arg0) {
  const ret = (0, _inline32.__cargo_web_snippet_dc2fd915bd92f9e9c6a3bd15174f1414eee3dbaf)(takeObject(arg0));
  return ret;
};

__exports.__wbg_cargowebsnippet97495987af1720d8a9a923fa4683a7b683e3acd6_d0a56c55c44e1eab = function (arg0, arg1, arg2) {
  const ret = (0, _inline31.__cargo_web_snippet_97495987af1720d8a9a923fa4683a7b683e3acd6)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet72fc447820458c720c68d0d8e078ede631edd723_9de68d30fbac283e = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline30.__cargo_web_snippet_72fc447820458c720c68d0d8e078ede631edd723)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippete9638d6405ab65f78daf4a5af9c9de14ecf1e2ec_2463c2b9bebdba37 = function (arg0, arg1) {
  const ret = (0, _inline28.__cargo_web_snippet_e9638d6405ab65f78daf4a5af9c9de14ecf1e2ec)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet6fcce0aae651e2d748e085ff1f800f87625ff8c8_1007837b54901836 = function (arg0, arg1) {
  const ret = (0, _inline27.__cargo_web_snippet_6fcce0aae651e2d748e085ff1f800f87625ff8c8)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet91749aeb589cd0f9b17cbc01b2872ba709817982_806cd7360f5a79e3 = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline26.__cargo_web_snippet_91749aeb589cd0f9b17cbc01b2872ba709817982)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippet352943ae98b2eeb817e36305c3531d61c7e1a52b_bae51ba456be6062 = function (arg0, arg1) {
  const ret = (0, _inline3.__cargo_web_snippet_352943ae98b2eeb817e36305c3531d61c7e1a52b)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet0e54fd9c163fcf648ce0a395fde4500fd167a40b_f53ff65bc255a6fd = function (arg0, arg1) {
  const ret = (0, _inline18.__cargo_web_snippet_0e54fd9c163fcf648ce0a395fde4500fd167a40b)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetafafe9a462a05084fec65cacc7d6598e145ff3e3_abbd53078ba324e9 = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline25.__cargo_web_snippet_afafe9a462a05084fec65cacc7d6598e145ff3e3)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippet0aced9e2351ced72f1ff99645a129132b16c0d3c_7830e6fa0c325bbe = function (arg0, arg1) {
  const ret = (0, _inline29.__cargo_web_snippet_0aced9e2351ced72f1ff99645a129132b16c0d3c)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetc023351d5bff43ef3dd317b499821cd4e71492f0_9ad84a1413bfb278 = function (arg0, arg1) {
  const ret = (0, _inline21.__cargo_web_snippet_c023351d5bff43ef3dd317b499821cd4e71492f0)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbindgen_cb_drop = function (arg0) {
  const obj = takeObject(arg0).original;

  if (obj.cnt-- == 1) {
    obj.a = 0;
    return true;
  }

  const ret = false;
  return ret;
};

__exports.__widl_f_performance_Window = function (arg0) {
  const ret = getObject(arg0).performance;
  return isLikeNone(ret) ? 0 : addHeapObject(ret);
};

__exports.__widl_f_now_Performance = function (arg0) {
  const ret = getObject(arg0).now();
  return ret;
};

__exports.__widl_f_set_timeout_with_callback_and_timeout_and_arguments_0_Window = function (arg0, arg1, arg2) {
  try {
    const ret = getObject(arg0).setTimeout(getObject(arg1), arg2);
    return ret;
  } catch (e) {
    handleError(e);
  }
};

__exports.__widl_instanceof_Window = function (arg0) {
  const ret = getObject(arg0) instanceof Window;
  return ret;
};

__exports.__wbg_resolve_4ca5ad5c0eb0abf1 = function (arg0) {
  const ret = Promise.resolve(getObject(arg0));
  return addHeapObject(ret);
};

__exports.__wbg_then_3bb8a69ecfd29434 = function (arg0, arg1) {
  const ret = getObject(arg0).then(getObject(arg1));
  return addHeapObject(ret);
};

__exports.__wbg_then_fb82bfc0e1d7f311 = function (arg0, arg1, arg2) {
  const ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
  return addHeapObject(ret);
};

__exports.__wbg_globalThis_8df2c73db5eac245 = function () {
  try {
    const ret = globalThis.globalThis;
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbg_self_937dd9f384d2384a = function () {
  try {
    const ret = self.self;
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbg_window_425d3fa09c43ece4 = function () {
  try {
    const ret = window.window;
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbg_global_2c090b42ef2744b9 = function () {
  try {
    const ret = global.global;
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbindgen_is_undefined = function (arg0) {
  const ret = getObject(arg0) === undefined;
  return ret;
};

__exports.__wbg_newnoargs_368b05293a3f44de = function (arg0, arg1) {
  const ret = new Function(getStringFromWasm(arg0, arg1));
  return addHeapObject(ret);
};

__exports.__wbg_call_1fc553129cb17c3c = function (arg0, arg1) {
  try {
    const ret = getObject(arg0).call(getObject(arg1));
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbg_set_09ce0f7f67d68b09 = function (arg0, arg1, arg2) {
  try {
    const ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
    return ret;
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbg_new_59cb74e423758ede = function () {
  const ret = new Error();
  return addHeapObject(ret);
};

__exports.__wbg_stack_558ba5917b466edd = function (arg0, arg1) {
  const ret = getObject(arg1).stack;
  const ret0 = passStringToWasm(ret);
  const ret1 = WASM_VECTOR_LEN;
  getInt32Memory()[arg0 / 4 + 0] = ret0;
  getInt32Memory()[arg0 / 4 + 1] = ret1;
};

__exports.__wbg_error_4bb6c2a97407129a = function (arg0, arg1) {
  const v0 = getStringFromWasm(arg0, arg1).slice();

  wasm.__wbindgen_free(arg0, arg1 * 1);

  console.error(v0);
};

__exports.__wbindgen_debug_string = function (arg0, arg1) {
  const ret = debugString(getObject(arg1));
  const ret0 = passStringToWasm(ret);
  const ret1 = WASM_VECTOR_LEN;
  getInt32Memory()[arg0 / 4 + 0] = ret0;
  getInt32Memory()[arg0 / 4 + 1] = ret1;
};

__exports.__wbindgen_throw = function (arg0, arg1) {
  throw new Error(getStringFromWasm(arg0, arg1));
};

__exports.__wbg_cargowebsnippet99c4eefdc8d4cc724135163b8c8665a1f3de99e4_9e0d114ccfe02ed8 = function (arg0, arg1, arg2, arg3, arg4) {
  const ret = (0, _inline22.__cargo_web_snippet_99c4eefdc8d4cc724135163b8c8665a1f3de99e4)(takeObject(arg0), arg1, arg2, arg3, arg4);
  return ret;
};

__exports.__wbg_cargowebsnippet906f13b1e97c3e6e6996c62d7584c4917315426d_ecb4ff9f812d4fea = function (arg0, arg1) {
  const ret = (0, _inline11.__cargo_web_snippet_906f13b1e97c3e6e6996c62d7584c4917315426d)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet85b9ecbdb8513465b790546acfd0cd530441b8a4_39b2097ead37af1f = function (arg0, arg1) {
  const ret = (0, _inline15.__cargo_web_snippet_85b9ecbdb8513465b790546acfd0cd530441b8a4)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippetff5103e6cc179d13b4c7a785bdce2708fd559fc0_09cfe7dd090af6e4 = function (arg0, arg1) {
  const ret = (0, _inline10.__cargo_web_snippet_ff5103e6cc179d13b4c7a785bdce2708fd559fc0)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippeta152e8d0e8fac5476f30c1d19e4ab217dbcba73d_aafd270ef79b709d = function (arg0, arg1, arg2, arg3) {
  const ret = (0, _inline24.__cargo_web_snippet_a152e8d0e8fac5476f30c1d19e4ab217dbcba73d)(takeObject(arg0), arg1, arg2, arg3);
  return ret;
};

__exports.__wbg_cargowebsnippet7c8dfab835dc8a552cd9d67f27d26624590e052c_785898ead5511e50 = function (arg0, arg1) {
  const ret = (0, _inline19.__cargo_web_snippet_7c8dfab835dc8a552cd9d67f27d26624590e052c)(takeObject(arg0), arg1);
  return ret;
};

__exports.__wbg_cargowebsnippet690311d2f9134ac0983620c38a9e6460d4165607_5bd9d7c7120a5a5d = function (arg0, arg1, arg2) {
  const ret = (0, _inline6.__cargo_web_snippet_690311d2f9134ac0983620c38a9e6460d4165607)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet08a3b15e1358700ac92bc556f9e9b8af660fc2c7_0e68a7739fb07b69 = function (arg0, arg1, arg2) {
  const ret = (0, _inline35.__cargo_web_snippet_08a3b15e1358700ac92bc556f9e9b8af660fc2c7)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippetbb618d13cbb219642bd219af99ee1519e5658d77_8cafa165cb2ad2fd = function (arg0, arg1, arg2) {
  const ret = (0, _inline5.__cargo_web_snippet_bb618d13cbb219642bd219af99ee1519e5658d77)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_new_abadb45e63451a4b = function () {
  const ret = new Object();
  return addHeapObject(ret);
};

__exports.__wbindgen_string_new = function (arg0, arg1) {
  const ret = getStringFromWasm(arg0, arg1);
  return addHeapObject(ret);
};

__exports.__widl_f_new_with_str_and_init_Request = function (arg0, arg1, arg2) {
  try {
    const ret = new Request(getStringFromWasm(arg0, arg1), getObject(arg2));
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__widl_f_fetch_with_request_Window = function (arg0, arg1) {
  const ret = getObject(arg0).fetch(getObject(arg1));
  return addHeapObject(ret);
};

__exports.__widl_instanceof_Response = function (arg0) {
  const ret = getObject(arg0) instanceof Response;
  return ret;
};

__exports.__widl_f_json_Response = function (arg0) {
  try {
    const ret = getObject(arg0).json();
    return addHeapObject(ret);
  } catch (e) {
    handleError(e);
  }
};

__exports.__wbindgen_json_serialize = function (arg0, arg1) {
  const ret = JSON.stringify(getObject(arg1));
  const ret0 = passStringToWasm(ret);
  const ret1 = WASM_VECTOR_LEN;
  getInt32Memory()[arg0 / 4 + 0] = ret0;
  getInt32Memory()[arg0 / 4 + 1] = ret1;
};

__exports.__wbg_cargowebsnippete741b9d9071097746386b2c2ec044a2bc73e688c_e4ba8c69a5f0ce29 = function (arg0, arg1, arg2) {
  const ret = (0, _inline39.__cargo_web_snippet_e741b9d9071097746386b2c2ec044a2bc73e688c)(takeObject(arg0), arg1, arg2);
  return ret;
};

__exports.__wbg_cargowebsnippet46518012593da937dd5f35c2fc1c5e1dcade260b_f74c704cb1d320a4 = function (arg0, arg1, arg2, arg3, arg4) {
  const ret = (0, _inline37.__cargo_web_snippet_46518012593da937dd5f35c2fc1c5e1dcade260b)(takeObject(arg0), arg1, arg2, arg3, arg4);
  return ret;
};

__exports.__wbindgen_closure_wrapper758 = function (arg0, arg1, arg2) {
  const state = {
    a: arg0,
    b: arg1,
    cnt: 1
  };

  const real = arg0 => {
    state.cnt++;

    try {
      return __wbg_elem_binding3(state.a, state.b, arg0);
    } finally {
      if (--state.cnt === 0) {
        wasm.__wbg_function_table.get(16)(state.a, state.b);

        state.a = 0;
      }
    }
  };

  real.original = state;
  const ret = real;
  return addHeapObject(ret);
};

__exports.__wbindgen_closure_wrapper2421 = function (arg0, arg1, arg2) {
  const state = {
    a: arg0,
    b: arg1,
    cnt: 1
  };

  const real = arg0 => {
    state.cnt++;
    const a = state.a;
    state.a = 0;

    try {
      return __wbg_elem_binding1(a, state.b, arg0);
    } finally {
      if (--state.cnt === 0) wasm.__wbg_function_table.get(26)(a, state.b);else state.a = a;
    }
  };

  real.original = state;
  const ret = real;
  return addHeapObject(ret);
};

__exports.__wbindgen_closure_wrapper754 = function (arg0, arg1, arg2) {
  const state = {
    a: arg0,
    b: arg1,
    cnt: 1
  };

  const real = (arg0, arg1) => {
    state.cnt++;

    try {
      return __wbg_elem_binding2(state.a, state.b, arg0, arg1);
    } finally {
      if (--state.cnt === 0) {
        wasm.__wbg_function_table.get(12)(state.a, state.b);

        state.a = 0;
      }
    }
  };

  real.original = state;
  const ret = real;
  return addHeapObject(ret);
};

__exports.__wbindgen_closure_wrapper1029 = function (arg0, arg1, arg2) {
  const state = {
    a: arg0,
    b: arg1,
    cnt: 1
  };

  const real = () => {
    state.cnt++;
    const a = state.a;
    state.a = 0;

    try {
      return __wbg_elem_binding0(a, state.b);
    } finally {
      if (--state.cnt === 0) wasm.__wbg_function_table.get(20)(a, state.b);else state.a = a;
    }
  };

  real.original = state;
  const ret = real;
  return addHeapObject(ret);
};

function init(wasm_path) {
  const fetchPromise = fetch(wasm_path);
  let resultPromise;

  if (typeof WebAssembly.instantiateStreaming === 'function') {
    resultPromise = WebAssembly.instantiateStreaming(fetchPromise, {
      './rust_parcel.js': __exports
    });
  } else {
    resultPromise = fetchPromise.then(response => response.arrayBuffer()).then(buffer => WebAssembly.instantiate(buffer, {
      './rust_parcel.js': __exports
    }));
  }

  return resultPromise.then(({
    instance
  }) => {
    wasm = init.wasm = instance.exports;
    return;
  });
}

;

function init_node(wasm_path) {
  const fs = require('fs');

  return new Promise(function (resolve, reject) {
    fs.readFile(__dirname + wasm_path, function (err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data.buffer);
      }
    });
  }).then(data => WebAssembly.instantiate(data, {
    './rust_parcel': __exports
  })).then(({
    instance
  }) => {
    wasm = init.wasm = instance.exports;
    return;
  });
}

const wasm_bindgen = Object.assign(false ? init_node : init, __exports);

module.exports = function loadWASMBundle(bundle) {
  return wasm_bindgen(bundle).then(() => __exports);
};
},{"../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline15.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline15.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline153.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline153.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline156.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline156.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline16.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline16.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline192.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline192.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline194.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline194.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline23.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline23.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline293.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline293.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline294.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline294.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline318.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline318.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline432.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline432.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline499.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline499.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline519.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline519.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline522.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline522.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline534.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline534.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline596.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline596.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline598.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline598.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline661.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline661.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline665.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline665.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline667.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline667.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline670.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline670.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline695.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline695.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline696.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline696.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline805.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline805.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline840.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline840.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline848.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline848.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline850.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline850.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline852.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline852.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline854.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline854.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline855.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline855.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline856.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline856.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline857.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline857.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline858.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline858.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline887.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline887.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline902.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline902.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline907.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline907.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline917.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline917.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline923.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline923.js","../../crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline924.js":"crate/pkg/snippets/stdweb-fdcd3965c5b71088/inline924.js","../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline0.js":"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline0.js","../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline1.js":"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline1.js","../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline2.js":"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline2.js","../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline3.js":"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline3.js","../../crate/pkg/snippets/web_logger-831cf3115fc27a05/inline4.js":"crate/pkg/snippets/web_logger-831cf3115fc27a05/inline4.js","../../crate/pkg/snippets/yew-55512dcf734c13d9/inline31.js":"crate/pkg/snippets/yew-55512dcf734c13d9/inline31.js","../../crate/pkg/snippets/yew-55512dcf734c13d9/inline32.js":"crate/pkg/snippets/yew-55512dcf734c13d9/inline32.js","../../crate/pkg/snippets/yew-55512dcf734c13d9/inline33.js":"crate/pkg/snippets/yew-55512dcf734c13d9/inline33.js","../../crate/pkg/snippets/yew-55512dcf734c13d9/inline34.js":"crate/pkg/snippets/yew-55512dcf734c13d9/inline34.js","../../crate/pkg/snippets/yew-55512dcf734c13d9/inline35.js":"crate/pkg/snippets/yew-55512dcf734c13d9/inline35.js","fs":"node_modules/parcel-bundler/src/builtins/_empty.js"}],0:[function(require,module,exports) {
var b=require("node_modules/parcel-bundler/src/builtins/bundle-loader.js");b.register("wasm",require("node_modules/parcel-plugin-wasm.rs/wasm-loader.js"));b.load([["rust_parcel_bg.f347b42c.wasm","crate/pkg/rust_parcel_bg.wasm"]]).then(function(){require("js/index.js");});
},{}]},{},["node_modules/parcel-bundler/src/builtins/hmr-runtime.js",0], null)
//# sourceMappingURL=/js.00a46daa.js.map